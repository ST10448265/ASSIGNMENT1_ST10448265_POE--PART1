using Microsoft.EntityFrameworkCore;
using RaceDay.API.Models;

namespace RaceDay.API.Data
{
    public class RaceDayDbContext : DbContext
    {
        public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options)
            : base(options) { }

        public DbSet<User> Users => Set<User>();
        public DbSet<Event> Events => Set<Event>();
        public DbSet<Category> Categories => Set<Category>();
        public DbSet<Enrolment> Enrolments => Set<Enrolment>();
        public DbSet<Result> Results => Set<Result>();
        public DbSet<EventRoute> EventRoutes => Set<EventRoute>();
        public DbSet<WeatherSnapshot> WeatherSnapshots => Set<WeatherSnapshot>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // USERS
            modelBuilder.Entity<User>(e =>
            {
                e.HasKey(u => u.UserId);
                e.HasIndex(u => u.Email).IsUnique();
                e.Property(u => u.Email).HasMaxLength(255).IsRequired();
                e.Property(u => u.FirstName).HasMaxLength(50).IsRequired();
                e.Property(u => u.LastName).HasMaxLength(50).IsRequired();
                e.Property(u => u.PasswordHash).HasMaxLength(255).IsRequired();
                e.Property(u => u.Phone).HasMaxLength(30);
                e.Property(u => u.Role).HasMaxLength(20).IsRequired();\n                e.Property(u => u.ProfilePictureUrl).HasMaxLength(2048);
                e.ToTable(t => t.HasCheckConstraint("CK_Users_Role",
                    "[Role] IN ('Organiser', 'Participant')"));
            });

            // EVENTS
            modelBuilder.Entity<Event>(e =>
            {
                e.HasKey(ev => ev.EventId);
                e.Property(ev => ev.Name).HasMaxLength(120).IsRequired();
                e.Property(ev => ev.Description).HasMaxLength(1000);
                e.Property(ev => ev.Location).HasMaxLength(150).IsRequired();
                e.Property(ev => ev.EventType).HasMaxLength(20).IsRequired();
                e.Property(ev => ev.Status).HasMaxLength(20).IsRequired();\n                e.Property(ev => ev.BannerImageUrl).HasMaxLength(2048);
                e.HasOne(ev => ev.Organiser)
                    .WithMany(u => u.OrganisedEvents)
                    .HasForeignKey(ev => ev.OrganiserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // CATEGORIES
            modelBuilder.Entity<Category>(e =>
            {
                e.HasKey(c => c.CategoryId);
                e.Property(c => c.Name).HasMaxLength(80).IsRequired();
                e.Property(c => c.DistanceKm).HasColumnType("decimal(5,2)");
                e.Property(c => c.EntryFee).HasColumnType("decimal(10,2)");
                e.HasIndex(c => new { c.EventId, c.Name }).IsUnique();
                e.HasOne(c => c.Event)
                    .WithMany(ev => ev.Categories)
                    .HasForeignKey(c => c.EventId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // ENROLMENTS
            modelBuilder.Entity<Enrolment>(e =>
            {
                e.HasKey(en => en.EnrolmentId);
                e.Property(en => en.Status).HasMaxLength(20).IsRequired();
                e.Property(en => en.BibNumber).HasMaxLength(20);
                e.HasIndex(en => new { en.ParticipantId, en.EventId, en.CategoryId }).IsUnique();
                e.HasOne(en => en.Participant)
                    .WithMany(u => u.Enrolments)
                    .HasForeignKey(en => en.ParticipantId)
                    .OnDelete(DeleteBehavior.Restrict);
                e.HasOne(en => en.Event)
                    .WithMany(ev => ev.Enrolments)
                    .HasForeignKey(en => en.EventId)
                    .OnDelete(DeleteBehavior.Restrict);
                e.HasOne(en => en.Category)
                    .WithMany(c => c.Enrolments)
                    .HasForeignKey(en => en.CategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // RESULTS
            modelBuilder.Entity<Result>(e =>
            {
                e.HasKey(r => r.ResultId);
                e.HasIndex(r => r.EnrolmentId).IsUnique();
                e.Property(r => r.ResultStatus).HasMaxLength(20).IsRequired();
                e.HasOne(r => r.Enrolment)
                    .WithOne(en => en.Result)
                    .HasForeignKey<Result>(r => r.EnrolmentId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // EVENT ROUTES
            modelBuilder.Entity<EventRoute>(e =>
            {
                e.HasKey(er => er.RouteId);
                e.HasIndex(er => er.EventId).IsUnique();
                e.Property(er => er.RouteName).HasMaxLength(120).IsRequired();
                e.Property(er => er.SurfaceType).HasMaxLength(50).IsRequired();
                e.Property(er => er.MapUrl).HasMaxLength(500);
                e.Property(er => er.DistanceKm).HasColumnType("decimal(5,2)");
                e.HasOne(er => er.Event)
                    .WithOne(ev => ev.Route)
                    .HasForeignKey<EventRoute>(er => er.EventId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // WEATHER SNAPSHOTS
            modelBuilder.Entity<WeatherSnapshot>(e =>
            {
                e.HasKey(w => w.WeatherId);
                e.Property(w => w.Condition).HasMaxLength(80).IsRequired();
                e.Property(w => w.TemperatureC).HasColumnType("decimal(5,2)");
                e.Property(w => w.WindSpeedKmh).HasColumnType("decimal(6,2)");
                e.HasOne(w => w.Event)
                    .WithMany(ev => ev.WeatherSnapshots)
                    .HasForeignKey(w => w.EventId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}

