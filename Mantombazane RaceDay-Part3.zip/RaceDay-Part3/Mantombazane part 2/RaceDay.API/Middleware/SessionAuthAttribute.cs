﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.API.Middleware
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class SessionAuthAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string? _requiredRole;

        public SessionAuthAttribute(string? requiredRole = null)
        {
            _requiredRole = requiredRole;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var userId = context.HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                context.Result = new UnauthorizedObjectResult(
                    new { message = "Authentication required." });
                return;
            }

            if (!string.IsNullOrEmpty(_requiredRole))
            {
                var role = context.HttpContext.Session.GetString("Role");
                if (role != _requiredRole)
                {
                    context.Result = new ObjectResult(
                        new { message = "Access denied. Insufficient permissions." })
                    {
                        StatusCode = 403
                    };
                }
            }
        }
    }
}