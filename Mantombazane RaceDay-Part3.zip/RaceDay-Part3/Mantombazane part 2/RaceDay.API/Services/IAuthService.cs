﻿namespace RaceDay.API.Services
{
    public interface IAuthService
    {
        Task<bool> RegisterAsync(string firstName, string lastName,
            string email, string password, string? phone, string role);
        Task<object?> LoginAsync(string email, string password);
    }
}
