﻿namespace RaceDay.API.Models
{
    public class Result
    {
        public int ResultId { get; set; }
        public int EnrolmentId { get; set; }
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string ResultStatus { get; set; } = "Finished"; // Finished, DNF, DNS, DSQ
        public DateTime RecordedAt { get; set; } = DateTime.UtcNow;

        // Navigation property
        public Enrolment Enrolment { get; set; } = null!;
    }
}
