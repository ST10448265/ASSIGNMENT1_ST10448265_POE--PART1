﻿
namespace RaceDay.API.Models
{
    public class WeatherSnapshot
    {
        public int WeatherId { get; set; }
        public int EventId { get; set; }
        public DateTime ForecastDate { get; set; }
        public decimal TemperatureC { get; set; }
        public string Condition { get; set; } = string.Empty;
        public decimal WindSpeedKmh { get; set; }
        public DateTime RetrievedAt { get; set; } = DateTime.UtcNow;

        // Navigation property
        public Event Event { get; set; } = null!;
    }
}