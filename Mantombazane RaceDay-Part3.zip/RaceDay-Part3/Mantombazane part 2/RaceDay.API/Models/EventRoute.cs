﻿
namespace RaceDay.API.Models
{
    public class EventRoute
    {
        public int RouteId { get; set; }
        public int EventId { get; set; }
        public string RouteName { get; set; } = string.Empty;
        public decimal DistanceKm { get; set; }
        public string SurfaceType { get; set; } = string.Empty;
        public string? MapUrl { get; set; }
        public int? ElevationGainM { get; set; }

        // Navigation property
        public Event Event { get; set; } = null!;
    }
}