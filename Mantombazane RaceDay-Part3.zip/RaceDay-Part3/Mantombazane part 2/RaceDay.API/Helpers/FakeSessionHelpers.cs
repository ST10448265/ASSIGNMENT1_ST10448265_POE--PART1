﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RaceDay.Tests.Helpers
{
    /// <summary>
    /// Creates a ControllerContext with a simulated logged-in session.
    /// </summary>
    public static class FakeSessionHelper
    {
        public static ControllerContext CreateContext(int? userId, string? role)
        {
            var httpContext = new DefaultHttpContext();
            var session = new FakeSession();

            if (userId.HasValue)
                session.SetInt32("UserId", userId.Value);

            if (!string.IsNullOrEmpty(role))
                session.SetString("Role", role);

            httpContext.Session = session;

            return new ControllerContext
            {
                HttpContext = httpContext
            };
        }
    }
}
