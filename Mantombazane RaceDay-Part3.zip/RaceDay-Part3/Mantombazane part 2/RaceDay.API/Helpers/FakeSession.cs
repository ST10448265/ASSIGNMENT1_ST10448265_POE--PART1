﻿using Microsoft.AspNetCore.Http;

namespace RaceDay.Tests.Helpers
{
    /// <summary>
    /// Minimal in-memory ISession implementation for testing controllers.
    /// </summary>
    public class FakeSession : ISession
    {
        private readonly Dictionary<string, byte[]> _store = new();

        public bool IsAvailable => true;
        public string Id => Guid.NewGuid().ToString();
        public IEnumerable<string> Keys => _store.Keys;

        public void Clear() => _store.Clear();

        public Task CommitAsync(CancellationToken cancellationToken = default)
            => Task.CompletedTask;

        public Task LoadAsync(CancellationToken cancellationToken = default)
            => Task.CompletedTask;

        public void Remove(string key) => _store.Remove(key);

        public void Set(string key, byte[] value) => _store[key] = value;

        public bool TryGetValue(string key, out byte[] value)
        {
            var found = _store.TryGetValue(key, out var v);
            value = v!;
            return found;
        }
    }
}