﻿using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;

namespace RaceDay.Tests.Helpers
{
    /// <summary>
    /// Creates a fresh in-memory database for each unit test.
    /// </summary>
    public static class TestDbFactory
    {
        public static RaceDayDbContext Create(string? dbName = null)
        {
            if (string.IsNullOrEmpty(dbName))
                dbName = Guid.NewGuid().ToString();

            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: dbName)
                .Options;

            var context = new RaceDayDbContext(options);
            context.Database.EnsureCreated();
            return context;
        }
    }
}