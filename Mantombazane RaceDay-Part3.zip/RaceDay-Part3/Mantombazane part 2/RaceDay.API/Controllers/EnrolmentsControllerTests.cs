﻿
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.Models;
using RaceDay.Tests.Helpers;
using Xunit;

namespace RaceDay.Tests.Controllers
{
    public class EnrolmentsControllerTests
    {
        private static RaceDayDbContext Seed()
        {
            var db = TestDbFactory.Create();

            db.Users.AddRange(
                new User
                {
                    UserId = 1,
                    FirstName = "Org",
                    LastName = "One",
                    Email = "org@test.com",
                    PasswordHash = "h",
                    Role = "Organiser"
                },
                new User
                {
                    UserId = 2,
                    FirstName = "Part",
                    LastName = "One",
                    Email = "part@test.com",
                    PasswordHash = "h",
                    Role = "Participant"
                },
                new User
                {
                    UserId = 3,
                    FirstName = "Part",
                    LastName = "Two",
                    Email = "part2@test.com",
                    PasswordHash = "h",
                    Role = "Participant"
                });

            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "Race",
                EventDate = DateTime.UtcNow.AddDays(10),
                Location = "JHB",
                EventType = "Running",
                Status = "Upcoming"
            });

            db.Categories.Add(new Category
            {
                CategoryId = 1,
                EventId = 1,
                Name = "10km",
                DistanceKm = 10m,
                MaxParticipants = 100,
                EntryFee = 150m,
                MinAge = 16
            });

            db.SaveChanges();
            return db;
        }

        // -------------------- ENROL --------------------

        [Fact]
        public async Task Enrol_ValidParticipant_Returns201()
        {
            using var db = Seed();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Participant")
            };

            var result = await controller.Enrol(1,
                new EnrolmentsController.EnrolRequest { CategoryId = 1 });

            result.Should().BeOfType<ObjectResult>()
                .Which.StatusCode.Should().Be(201);

            db.Enrolments.Should().HaveCount(1);
            var e = db.Enrolments.First();
            e.ParticipantId.Should().Be(2);
            e.EventId.Should().Be(1);
            e.CategoryId.Should().Be(1);
            e.Status.Should().Be("Confirmed");
        }

        [Fact]
        public async Task Enrol_Duplicate_Returns409()
        {
            using var db = Seed();

            db.Enrolments.Add(new Enrolment
            {
                ParticipantId = 2,
                EventId = 1,
                CategoryId = 1,
                Status = "Confirmed"
            });
            await db.SaveChangesAsync();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Participant")
            };

            var result = await controller.Enrol(1,
                new EnrolmentsController.EnrolRequest { CategoryId = 1 });

            result.Should().BeOfType<ConflictObjectResult>();
        }

        [Fact]
        public async Task Enrol_InvalidCategory_Returns400()
        {
            using var db = Seed();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Participant")
            };

            var result = await controller.Enrol(1,
                new EnrolmentsController.EnrolRequest { CategoryId = 999 });

            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Enrol_EventNotFound_Returns404()
        {
            using var db = Seed();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Participant")
            };

            var result = await controller.Enrol(999,
                new EnrolmentsController.EnrolRequest { CategoryId = 1 });

            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task Enrol_FullCategory_Returns400()
        {
            using var db = TestDbFactory.Create();

            db.Users.AddRange(
                new User
                {
                    UserId = 1,
                    FirstName = "O",
                    LastName = "1",
                    Email = "o@t.com",
                    PasswordHash = "h",
                    Role = "Organiser"
                },
                new User
                {
                    UserId = 2,
                    FirstName = "P",
                    LastName = "1",
                    Email = "p@t.com",
                    PasswordHash = "h",
                    Role = "Participant"
                },
                new User
                {
                    UserId = 3,
                    FirstName = "P",
                    LastName = "2",
                    Email = "p2@t.com",
                    PasswordHash = "h",
                    Role = "Participant"
                });

            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "R",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "L",
                EventType = "Running",
                Status = "Upcoming"
            });

            db.Categories.Add(new Category
            {
                CategoryId = 1,
                EventId = 1,
                Name = "Small",
                DistanceKm = 5m,
                MaxParticipants = 1,
                EntryFee = 50m
            });

            db.Enrolments.Add(new Enrolment
            {
                ParticipantId = 3,
                EventId = 1,
                CategoryId = 1,
                Status = "Confirmed"
            });

            await db.SaveChangesAsync();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Participant")
            };

            var result = await controller.Enrol(1,
                new EnrolmentsController.EnrolRequest { CategoryId = 1 });

            result.Should().BeOfType<BadRequestObjectResult>();
        }

        // -------------------- MY ENROLMENTS --------------------

        [Fact]
        public async Task MyEnrolments_Returns200()
        {
            using var db = Seed();

            db.Enrolments.AddRange(
                new Enrolment { ParticipantId = 2, EventId = 1, CategoryId = 1, Status = "Confirmed" },
                new Enrolment { ParticipantId = 3, EventId = 1, CategoryId = 1, Status = "Confirmed" });
            await db.SaveChangesAsync();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Participant")
            };

            var result = await controller.MyEnrolments();
            result.Should().BeOfType<OkObjectResult>();
        }

        // -------------------- GET FOR EVENT --------------------

        [Fact]
        public async Task GetForEvent_OwnerOrganiser_Returns200()
        {
            using var db = Seed();

            db.Enrolments.Add(new Enrolment
            {
                ParticipantId = 2,
                EventId = 1,
                CategoryId = 1,
                Status = "Confirmed"
            });
            await db.SaveChangesAsync();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(1, "Organiser")
            };

            var result = await controller.GetForEvent(1);
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetForEvent_NonOwnerOrganiser_Returns403()
        {
            using var db = Seed();

            db.Users.Add(new User
            {
                UserId = 10,
                FirstName = "Other",
                LastName = "Org",
                Email = "other@t.com",
                PasswordHash = "h",
                Role = "Organiser"
            });
            await db.SaveChangesAsync();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(10, "Organiser")
            };

            var result = await controller.GetForEvent(1);
            var obj = result.Should().BeOfType<ObjectResult>().Subject;
            obj.StatusCode.Should().Be(403);
        }

        // -------------------- UPDATE STATUS --------------------

        [Fact]
        public async Task UpdateStatus_ParticipantOwnEnrolment_Returns200()
        {
            using var db = Seed();

            db.Enrolments.Add(new Enrolment
            {
                EnrolmentId = 1,
                ParticipantId = 2,
                EventId = 1,
                CategoryId = 1,
                Status = "Confirmed"
            });
            await db.SaveChangesAsync();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Participant")
            };

            var result = await controller.UpdateStatus(1,
                new EnrolmentsController.EnrolStatusUpdate { Status = "Cancelled" });

            result.Should().BeOfType<OkObjectResult>();
            (await db.Enrolments.FindAsync(1))!.Status.Should().Be("Cancelled");
        }

        [Fact]
        public async Task UpdateStatus_OtherParticipantsEnrolment_Returns403()
        {
            using var db = Seed();

            db.Enrolments.Add(new Enrolment
            {
                EnrolmentId = 1,
                ParticipantId = 2,
                EventId = 1,
                CategoryId = 1,
                Status = "Confirmed"
            });
            await db.SaveChangesAsync();

            var controller = new EnrolmentsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(3, "Participant")
            };

            var result = await controller.UpdateStatus(1,
                new EnrolmentsController.EnrolStatusUpdate { Status = "Cancelled" });

            var obj = result.Should().BeOfType<ObjectResult>().Subject;
            obj.StatusCode.Should().Be(403);
        }
    }
}