﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Middleware;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/users")]
    [SessionAuth]
    public class UsersController : ControllerBase
    {
        private readonly RaceDayDbContext _db;

        public UsersController(RaceDayDbContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Get current user's profile.
        /// </summary>
        [HttpGet("profile")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetProfile()
        {
            var userId = HttpContext.Session.GetInt32("UserId")!.Value;
            var user = await _db.Users.FindAsync(userId);
            if (user == null) return NotFound();

            return Ok(new UserProfileDto
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Phone = user.Phone,
                Role = user.Role
            });
        }

        /// <summary>
        /// Update current user's profile.
        /// </summary>
        [HttpPut("profile")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileDto dto)
        {
            var userId = HttpContext.Session.GetInt32("UserId")!.Value;
            var user = await _db.Users.FindAsync(userId);
            if (user == null) return NotFound();

            user.FirstName = dto.FirstName;
            user.LastName = dto.LastName;
            if (!string.IsNullOrWhiteSpace(dto.Email))
            {
                var emailTaken = await _db.Users.AnyAsync(u =>
                    u.Email == dto.Email && u.UserId != userId);
                if (emailTaken)
                    return BadRequest(new { message = "Email is already in use." });

                user.Email = dto.Email;
                HttpContext.Session.SetString("Email", dto.Email);
            }
            user.Phone = dto.Phone;

            await _db.SaveChangesAsync();

            return Ok(new UserProfileDto
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Phone = user.Phone,
                Role = user.Role
            });
        }
    }
}