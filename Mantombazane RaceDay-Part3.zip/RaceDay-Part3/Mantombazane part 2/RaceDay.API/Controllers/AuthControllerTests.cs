﻿using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Controllers;
using RaceDay.API.DTOs;
using RaceDay.API.Helpers;
using RaceDay.API.Models;
using RaceDay.Tests.Helpers;
using Xunit;

namespace RaceDay.Tests.Controllers
{
    public class AuthControllerTests
    {
        // -------------------- REGISTER --------------------

        [Fact]
        public async Task Register_ValidParticipant_Returns201()
        {
            using var db = TestDbFactory.Create();
            var controller = new AuthController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(null, null)
            };

            var dto = new RegisterDto
            {
                FirstName = "John",
                LastName = "Smith",
                Email = "john@test.com",
                Password = "Password123!",
                Phone = "0712345678",
                Role = "Participant"
            };

            var result = await controller.Register(dto);

            result.Should().BeOfType<ObjectResult>()
                .Which.StatusCode.Should().Be(201);

            var user = await db.Users.FirstOrDefaultAsync(u => u.Email == "john@test.com");
            user.Should().NotBeNull();
            user!.Role.Should().Be("Participant");
            user.PasswordHash.Should().NotBe("Password123!");
            PasswordHelper.VerifyPassword("Password123!", user.PasswordHash).Should().BeTrue();
        }

        [Fact]
        public async Task Register_ValidOrganiser_Returns201()
        {
            using var db = TestDbFactory.Create();
            var controller = new AuthController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(null, null)
            };

            var dto = new RegisterDto
            {
                FirstName = "Thabo",
                LastName = "Mokoena",
                Email = "thabo@test.com",
                Password = "Pass123!",
                Role = "Organiser"
            };

            var result = await controller.Register(dto);

            result.Should().BeOfType<ObjectResult>()
                .Which.StatusCode.Should().Be(201);
        }

        [Fact]
        public async Task Register_InvalidRole_Returns400()
        {
            using var db = TestDbFactory.Create();
            var controller = new AuthController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(null, null)
            };

            var dto = new RegisterDto
            {
                FirstName = "Bad",
                LastName = "Role",
                Email = "bad@test.com",
                Password = "Pass123!",
                Role = "Admin"
            };

            var result = await controller.Register(dto);
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Register_DuplicateEmail_Returns409()
        {
            using var db = TestDbFactory.Create();

            db.Users.Add(new User
            {
                FirstName = "Existing",
                LastName = "User",
                Email = "dup@test.com",
                PasswordHash = PasswordHelper.HashPassword("Pass123!"),
                Role = "Participant"
            });
            await db.SaveChangesAsync();

            var controller = new AuthController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(null, null)
            };

            var dto = new RegisterDto
            {
                FirstName = "New",
                LastName = "User",
                Email = "dup@test.com",
                Password = "Pass123!",
                Role = "Participant"
            };

            var result = await controller.Register(dto);
            result.Should().BeOfType<ConflictObjectResult>();
        }

        // -------------------- LOGIN --------------------

        [Fact]
        public async Task Login_CorrectCredentials_Returns200AndSetsSession()
        {
            using var db = TestDbFactory.Create();

            db.Users.Add(new User
            {
                UserId = 1,
                FirstName = "Aisha",
                LastName = "Khumalo",
                Email = "aisha@test.com",
                PasswordHash = PasswordHelper.HashPassword("Pass123!"),
                Role = "Participant"
            });
            await db.SaveChangesAsync();

            var httpContext = new DefaultHttpContext { Session = new FakeSession() };
            var controller = new AuthController(db)
            {
                ControllerContext = new ControllerContext { HttpContext = httpContext }
            };

            var result = await controller.Login(new LoginDto
            {
                Email = "aisha@test.com",
                Password = "Pass123!"
            });

            result.Should().BeOfType<OkObjectResult>();
            httpContext.Session.GetString("Role").Should().Be("Participant");
            httpContext.Session.GetInt32("UserId").Should().Be(1);
        }

        [Fact]
        public async Task Login_WrongPassword_Returns401()
        {
            using var db = TestDbFactory.Create();

            db.Users.Add(new User
            {
                FirstName = "Test",
                LastName = "User",
                Email = "test@test.com",
                PasswordHash = PasswordHelper.HashPassword("CorrectPass!"),
                Role = "Participant"
            });
            await db.SaveChangesAsync();

            var controller = new AuthController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(null, null)
            };

            var result = await controller.Login(new LoginDto
            {
                Email = "test@test.com",
                Password = "WrongPass!"
            });

            result.Should().BeOfType<UnauthorizedObjectResult>();
        }

        [Fact]
        public async Task Login_UnknownEmail_Returns401()
        {
            using var db = TestDbFactory.Create();
            var controller = new AuthController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(null, null)
            };

            var result = await controller.Login(new LoginDto
            {
                Email = "nobody@test.com",
                Password = "AnyPass!"
            });

            result.Should().BeOfType<UnauthorizedObjectResult>();
        }
    }
}