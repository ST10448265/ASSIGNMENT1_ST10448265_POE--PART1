﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Middleware;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api")]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _db;

        public ResultsController(RaceDayDbContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Record a result for an enrolment (Organiser only).
        /// </summary>
        [HttpPost("enrollments/{enrolmentId}/result")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> Create(int enrolmentId, [FromBody] ResultInput req)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;

            var enrolment = await _db.Enrolments
                .Include(e => e.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentId == enrolmentId);

            if (enrolment == null) return NotFound(new { message = "Enrolment not found." });
            if (enrolment.Event.OrganiserId != organiserId)
                return StatusCode(403, new { message = "Access denied." });

            var exists = await _db.Results.AnyAsync(r => r.EnrolmentId == enrolmentId);
            if (exists)
                return Conflict(new { message = "Result already exists for this enrolment." });

            var result = new Result
            {
                EnrolmentId = enrolmentId,
                FinishTime = req.FinishTime,
                Position = req.Position,
                ResultStatus = req.ResultStatus ?? "Finished",
                RecordedAt = DateTime.UtcNow
            };

            _db.Results.Add(result);
            await _db.SaveChangesAsync();

            return StatusCode(201, result);
        }

        /// <summary>
        /// Get result for a specific enrolment (authorised participant or organiser).
        /// </summary>
        [HttpGet("enrollments/{enrolmentId}/result")]
        [SessionAuth]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetForEnrolment(int enrolmentId)
        {
            var userId = HttpContext.Session.GetInt32("UserId")!.Value;
            var role = HttpContext.Session.GetString("Role");

            var enrolment = await _db.Enrolments
                .Include(e => e.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentId == enrolmentId);

            if (enrolment == null) return NotFound();

            if (role == "Participant" && enrolment.ParticipantId != userId)
                return StatusCode(403, new { message = "Access denied." });

            if (role == "Organiser" && enrolment.Event.OrganiserId != userId)
                return StatusCode(403, new { message = "Access denied." });

            var result = await _db.Results
                .FirstOrDefaultAsync(r => r.EnrolmentId == enrolmentId);

            if (result == null) return NotFound(new { message = "Result not recorded yet." });
            return Ok(result);
        }

        /// <summary>
        /// Get all results for an event (leaderboard). Public.
        /// </summary>
        [HttpGet("events/{eventId}/results")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetForEvent(int eventId)
        {
            var results = await _db.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Participant)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                .Where(r => r.Enrolment.EventId == eventId)
                .OrderBy(r => r.Position)
                .Select(r => new
                {
                    r.ResultId,
                    r.FinishTime,
                    r.Position,
                    r.ResultStatus,
                    Participant = new
                    {
                        r.Enrolment.Participant.UserId,
                        r.Enrolment.Participant.FirstName,
                        r.Enrolment.Participant.LastName
                    },
                    Category = new { r.Enrolment.Category.Name }
                })
                .ToListAsync();

            return Ok(results);
        }

        /// <summary>
        /// Get the current participant's personal results history.
        /// </summary>
        [HttpGet("results/me")]
        [SessionAuth("Participant")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> MyResults()
        {
            var participantId = HttpContext.Session.GetInt32("UserId")!.Value;

            var results = await _db.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Event)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                .Where(r => r.Enrolment.ParticipantId == participantId)
                .Select(r => new
                {
                    r.ResultId,
                    r.FinishTime,
                    r.Position,
                    r.ResultStatus,
                    r.RecordedAt,
                    Event = new
                    {
                        r.Enrolment.Event.EventId,
                        r.Enrolment.Event.Name,
                        r.Enrolment.Event.EventDate
                    },
                    Category = new { r.Enrolment.Category.Name }
                })
                .ToListAsync();

            return Ok(results);
        }

        /// <summary>
        /// Update an existing result (Organiser only).
        /// </summary>
        [HttpPut("enrollments/{enrolmentId}/result")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Update(int enrolmentId, [FromBody] ResultInput req)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;

            var result = await _db.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Event)
                .FirstOrDefaultAsync(r => r.EnrolmentId == enrolmentId);

            if (result == null) return NotFound();
            if (result.Enrolment.Event.OrganiserId != organiserId)
                return StatusCode(403, new { message = "Access denied." });

            result.FinishTime = req.FinishTime;
            result.Position = req.Position;
            result.ResultStatus = req.ResultStatus ?? result.ResultStatus;

            await _db.SaveChangesAsync();
            return Ok(result);
        }

        /// <summary>
        /// Delete a result (Organiser only).
        /// </summary>
        [HttpDelete("enrollments/{enrolmentId}/result")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Delete(int enrolmentId)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;

            var result = await _db.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Event)
                .FirstOrDefaultAsync(r => r.EnrolmentId == enrolmentId);

            if (result == null) return NotFound();
            if (result.Enrolment.Event.OrganiserId != organiserId)
                return StatusCode(403, new { message = "Access denied." });

            _db.Results.Remove(result);
            await _db.SaveChangesAsync();
            return NoContent();
        }

        public class ResultInput
        {
            public TimeSpan? FinishTime { get; set; }
            public int? Position { get; set; }
            public string? ResultStatus { get; set; }
        }
    }
}