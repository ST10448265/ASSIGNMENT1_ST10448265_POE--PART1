using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Middleware;

namespace RaceDay.API.Controllers;

[ApiController]
[Route("api")]
public class BlobUploadsController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IConfiguration _configuration;
    public BlobUploadsController(RaceDayDbContext db, IConfiguration configuration)
    { _db = db; _configuration = configuration; }

    private async Task<string> SaveImageAsync(IFormFile file, string folder, CancellationToken ct)
    {
        var allowed = new[] { "image/jpeg", "image/png", "image/webp" };
        if (!allowed.Contains(file.ContentType, StringComparer.OrdinalIgnoreCase))
            throw new ArgumentException("Only JPEG, PNG and WebP images are accepted.");
        if (file.Length <= 0 || file.Length > 5 * 1024 * 1024)
            throw new ArgumentException("Image must be between 1 byte and 5 MB.");

        var connection = _configuration["AzureBlobStorage:ConnectionString"];
        var containerName = _configuration["AzureBlobStorage:Container"] ?? "raceday-images";
        if (string.IsNullOrWhiteSpace(connection))
            throw new InvalidOperationException("Azure Blob Storage is not configured. Set AzureBlobStorage:ConnectionString.");
        var service = new BlobServiceClient(connection);
        var container = service.GetBlobContainerClient(containerName);
        await container.CreateIfNotExistsAsync(cancellationToken: ct);
        var extension = Path.GetExtension(Path.GetFileName(file.FileName));
        var blob = container.GetBlobClient($"{folder}/{Guid.NewGuid():N}{extension}");
        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream, overwrite: false, cancellationToken: ct);
        return blob.Uri.ToString();
    }

    [HttpPost("events/{eventId:int}/banner"), SessionAuth("Organiser")]
    [RequestSizeLimit(5 * 1024 * 1024)]
    public async Task<IActionResult> UploadEventBanner(int eventId, IFormFile file, CancellationToken ct)
    {
        var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventId == eventId, ct);
        if (ev == null) return NotFound(new { message = "Event not found." });
        if (ev.OrganiserId != organiserId) return Forbid();
        try { ev.BannerImageUrl = await SaveImageAsync(file, "event-banners", ct); }
        catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
        catch (InvalidOperationException ex) { return StatusCode(503, new { message = ex.Message }); }
        await _db.SaveChangesAsync(ct);
        return Ok(new { imageUrl = ev.BannerImageUrl });
    }

    [HttpPost("users/profile-picture"), SessionAuth]
    [RequestSizeLimit(5 * 1024 * 1024)]
    public async Task<IActionResult> UploadProfilePicture(IFormFile file, CancellationToken ct)
    {
        var userId = HttpContext.Session.GetInt32("UserId")!.Value;
        var user = await _db.Users.FindAsync(new object[] { userId }, ct);
        if (user == null) return NotFound();
        try { user.ProfilePictureUrl = await SaveImageAsync(file, "profile-pictures", ct); }
        catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
        catch (InvalidOperationException ex) { return StatusCode(503, new { message = ex.Message }); }
        await _db.SaveChangesAsync(ct);
        return Ok(new { imageUrl = user.ProfilePictureUrl });
    }
}
