﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Middleware;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/events")]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _db;

        public EventsController(RaceDayDbContext db)
        {
            _db = db;
        }

        /// <summary>
        /// List all events. Optional filter by status.
        /// </summary>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAll([FromQuery] string? status)
        {
            var query = _db.Events.AsQueryable();

            if (!string.IsNullOrWhiteSpace(status))
                query = query.Where(e => e.Status == status);

            var events = await query
                .Select(e => new
                {
                    e.EventId,
                    e.Name,
                    e.EventDate,
                    e.Location,
                    e.EventType,
                    e.Status,
                    e.OrganiserId
                })
                .ToListAsync();

            return Ok(events);
        }

        /// <summary>
        /// Get one event with categories.
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int id)
        {
            var ev = await _db.Events
                .Include(e => e.Categories)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (ev == null) return NotFound(new { message = "Event not found." });
            return Ok(ev);
        }

        /// <summary>
        /// Create a new event (Organiser only).
        /// </summary>
        [HttpPost]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> Create([FromBody] Event model)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
            model.OrganiserId = organiserId;
            model.CreatedAt = DateTime.UtcNow;
            model.EventId = 0;

            _db.Events.Add(model);
            await _db.SaveChangesAsync();

            return StatusCode(201, model);
        }

        /// <summary>
        /// Update an existing event (Organiser of that event only).
        /// </summary>
        [HttpPut("{id}")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Update(int id, [FromBody] Event model)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
            var ev = await _db.Events.FindAsync(id);

            if (ev == null) return NotFound(new { message = "Event not found." });
            if (ev.OrganiserId != organiserId)
                return StatusCode(403, new { message = "You do not own this event." });

            ev.Name = model.Name;
            ev.Description = model.Description;
            ev.EventDate = model.EventDate;
            ev.Location = model.Location;
            ev.EventType = model.EventType;
            ev.Status = model.Status;

            await _db.SaveChangesAsync();
            return Ok(ev);
        }

        /// <summary>
        /// Delete an event (Organiser of that event only).
        /// </summary>
        [HttpDelete("{id}")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Delete(int id)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
            var ev = await _db.Events.FindAsync(id);

            if (ev == null) return NotFound(new { message = "Event not found." });
            if (ev.OrganiserId != organiserId)
                return StatusCode(403, new { message = "You do not own this event." });

            _db.Events.Remove(ev);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
