﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Middleware;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api")]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _db;

        public CategoriesController(RaceDayDbContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Get all categories for an event (public).
        /// </summary>
        [HttpGet("events/{eventId}/categories")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetForEvent(int eventId)
        {
            var cats = await _db.Categories
                .Where(c => c.EventId == eventId)
                .ToListAsync();

            return Ok(cats);
        }

        /// <summary>
        /// Get a single category by ID (public).
        /// </summary>
        [HttpGet("categories/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int id)
        {
            var cat = await _db.Categories.FindAsync(id);
            if (cat == null) return NotFound();
            return Ok(cat);
        }

        /// <summary>
        /// Add a new category to an event (Organiser only).
        /// </summary>
        [HttpPost("events/{eventId}/categories")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Create(int eventId, [FromBody] Category model)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
            var ev = await _db.Events.FindAsync(eventId);

            if (ev == null) return NotFound(new { message = "Event not found." });
            if (ev.OrganiserId != organiserId)
                return StatusCode(403, new { message = "You do not own this event." });

            model.EventId = eventId;
            model.CategoryId = 0;

            _db.Categories.Add(model);
            await _db.SaveChangesAsync();

            return StatusCode(201, model);
        }

        /// <summary>
        /// Update a category (Organiser of parent event only).
        /// </summary>
        [HttpPut("categories/{id}")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Update(int id, [FromBody] Category model)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
            var cat = await _db.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (cat == null) return NotFound();
            if (cat.Event.OrganiserId != organiserId)
                return StatusCode(403, new { message = "Access denied." });

            cat.Name = model.Name;
            cat.DistanceKm = model.DistanceKm;
            cat.MaxParticipants = model.MaxParticipants;
            cat.EntryFee = model.EntryFee;
            cat.MinAge = model.MinAge;
            cat.MaxAge = model.MaxAge;

            await _db.SaveChangesAsync();
            return Ok(cat);
        }

        /// <summary>
        /// Delete a category (Organiser of parent event only).
        /// </summary>
        [HttpDelete("categories/{id}")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Delete(int id)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
            var cat = await _db.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (cat == null) return NotFound();
            if (cat.Event.OrganiserId != organiserId)
                return StatusCode(403, new { message = "Access denied." });

            _db.Categories.Remove(cat);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}