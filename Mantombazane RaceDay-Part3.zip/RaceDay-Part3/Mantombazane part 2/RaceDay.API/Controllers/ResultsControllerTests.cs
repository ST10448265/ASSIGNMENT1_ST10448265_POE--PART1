﻿using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.Models;
using RaceDay.Tests.Helpers;
using Xunit;

namespace RaceDay.Tests.Controllers
{
    public class ResultsControllerTests
    {
        private static RaceDayDbContext Seed()
        {
            var db = TestDbFactory.Create();

            db.Users.AddRange(
                new User
                {
                    UserId = 1,
                    FirstName = "O",
                    LastName = "1",
                    Email = "o@t.com",
                    PasswordHash = "h",
                    Role = "Organiser"
                },
                new User
                {
                    UserId = 2,
                    FirstName = "P",
                    LastName = "1",
                    Email = "p@t.com",
                    PasswordHash = "h",
                    Role = "Participant"
                });

            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "R",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "L",
                EventType = "Running",
                Status = "Upcoming"
            });

            db.Categories.Add(new Category
            {
                CategoryId = 1,
                EventId = 1,
                Name = "10km",
                DistanceKm = 10m,
                MaxParticipants = 100,
                EntryFee = 100m
            });

            db.Enrolments.Add(new Enrolment
            {
                EnrolmentId = 1,
                ParticipantId = 2,
                EventId = 1,
                CategoryId = 1,
                Status = "Confirmed"
            });

            db.SaveChanges();
            return db;
        }

        // -------------------- CREATE --------------------

        [Fact]
        public async Task Create_OwnerOrganiser_Returns201()
        {
            using var db = Seed();

            var controller = new ResultsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(1, "Organiser")
            };

            var result = await controller.Create(1, new ResultsController.ResultInput
            {
                FinishTime = TimeSpan.FromMinutes(55),
                Position = 12,
                ResultStatus = "Finished"
            });

            result.Should().BeOfType<ObjectResult>()
                .Which.StatusCode.Should().Be(201);

            db.Results.Should().HaveCount(1);
        }

        [Fact]
        public async Task Create_DuplicateResult_Returns409()
        {
            using var db = Seed();

            db.Results.Add(new Result
            {
                EnrolmentId = 1,
                FinishTime = TimeSpan.FromMinutes(50),
                Position = 5,
                ResultStatus = "Finished"
            });
            await db.SaveChangesAsync();

            var controller = new ResultsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(1, "Organiser")
            };

            var result = await controller.Create(1, new ResultsController.ResultInput
            {
                FinishTime = TimeSpan.FromMinutes(55),
                Position = 6,
                ResultStatus = "Finished"
            });

            result.Should().BeOfType<ConflictObjectResult>();
        }

        [Fact]
        public async Task Create_NonOwnerOrganiser_Returns403()
        {
            using var db = Seed();

            db.Users.Add(new User
            {
                UserId = 3,
                FirstName = "O2",
                LastName = "Two",
                Email = "o2@t.com",
                PasswordHash = "h",
                Role = "Organiser"
            });
            await db.SaveChangesAsync();

            var controller = new ResultsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(3, "Organiser")
            };

            var result = await controller.Create(1, new ResultsController.ResultInput
            {
                FinishTime = TimeSpan.FromMinutes(55),
                Position = 6,
                ResultStatus = "Finished"
            });

            var obj = result.Should().BeOfType<ObjectResult>().Subject;
            obj.StatusCode.Should().Be(403);
        }

        [Fact]
        public async Task Create_En