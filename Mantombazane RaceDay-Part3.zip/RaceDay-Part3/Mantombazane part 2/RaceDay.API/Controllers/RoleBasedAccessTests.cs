﻿
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using RaceDay.API.Controllers;
using RaceDay.API.Middleware;
using RaceDay.Tests.Helpers;
using Xunit;

namespace RaceDay.Tests.Controllers
{
    public class RoleBasedAccessTests
    {
        // -------------------- ATTRIBUTE PRESENCE --------------------

        [Fact]
        public void Events_Create_RequiresOrganiserRole()
        {
            var method = typeof(EventsController).GetMethod("Create")!;
            var attrs = method.GetCustomAttributes(typeof(SessionAuthAttribute), true);
            attrs.Should().NotBeEmpty();
        }

        [Fact]
        public void Events_Update_RequiresOrganiserRole()
        {
            var method = typeof(EventsController).GetMethod("Update")!;
            var attrs = method.GetCustomAttributes(typeof(SessionAuthAttribute), true);
            attrs.Should().NotBeEmpty();
        }

        [Fact]
        public void Events_Delete_RequiresOrganiserRole()
        {
            var method = typeof(EventsController).GetMethod("Delete")!;
            var attrs = method.GetCustomAttributes(typeof(SessionAuthAttribute), true);
            attrs.Should().NotBeEmpty();
        }

        [Fact]
        public void Enrolments_Enrol_RequiresParticipantRole()
        {
            var method = typeof(EnrolmentsController).GetMethod("Enrol")!;
            var attrs = method.GetCustomAttributes(typeof(SessionAuthAttribute), true);
            attrs.Should().NotBeEmpty();
        }

        [Fact]
        public void Results_Create_RequiresOrganiserRole()
        {
            var method = typeof(ResultsController).GetMethod("Create")!;
            var attrs = method.GetCustomAttributes(typeof(SessionAuthAttribute), true);
            attrs.Should().NotBeEmpty();
        }

        // -------------------- SESSION AUTH BEHAVIOUR --------------------

        [Fact]
        public void SessionAuth_NoSession_Returns401()
        {
            var attribute = new SessionAuthAttribute();

            var httpContext = new DefaultHttpContext { Session = new FakeSession() };
            var context = BuildAuthContext(httpContext);

            attribute.OnAuthorization(context);

            context.Result.Should().BeOfType<UnauthorizedObjectResult>();
        }

        [Fact]
        public void SessionAuth_WrongRole_Returns403()
        {
            var attribute = new SessionAuthAttribute("Organiser");

            var session = new FakeSession();
            session.SetInt32("UserId", 1);
            session.SetString("Role", "Participant");

            var httpContext = new DefaultHttpContext { Session = session };
            var context = BuildAuthContext(httpContext);

            attribute.OnAuthorization(context);

            var result = context.Result.Should().BeOfType<ObjectResult>().Subject;
            result.StatusCode.Should().Be(403);
        }

        [Fact]
        public void SessionAuth_CorrectRole_Passes()
        {
            var attribute = new SessionAuthAttribute("Organiser");

            var session = new FakeSession();
            session.SetInt32("UserId", 1);
            session.SetString("Role", "Organiser");

            var httpContext = new DefaultHttpContext { Session = session };
            var context = BuildAuthContext(httpContext);

            attribute.OnAuthorization(context);

            context.Result.Should().BeNull();
        }

        [Fact]
        public void SessionAuth_AnyRole_PassesWhenAuthenticated()
        {
            var attribute = new SessionAuthAttribute(); // no role required

            var session = new FakeSession();
            session.SetInt32("UserId", 5);
            session.SetString("Role", "Participant");

            var httpContext = new DefaultHttpContext { Session = session };
            var context = BuildAuthContext(httpContext);

            attribute.OnAuthorization(context);

            context.Result.Should().BeNull();
        }

        private static AuthorizationFilterContext BuildAuthContext(HttpContext httpContext)
        {
            var actionContext = new ActionContext(
                httpContext,
                new RouteData(),
                new ActionDescriptor());

            return new AuthorizationFilterContext(
                actionContext,
                new List<IFilterMetadata>());
        }
    }
}