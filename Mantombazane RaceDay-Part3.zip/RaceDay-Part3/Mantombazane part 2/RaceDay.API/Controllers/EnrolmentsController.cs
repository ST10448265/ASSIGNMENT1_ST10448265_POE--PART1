﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Middleware;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api")]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _db;

        public EnrolmentsController(RaceDayDbContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Enrol the current participant in an event by selecting a category.
        /// </summary>
        [HttpPost("events/{eventId}/enrol")]
        [SessionAuth("Participant")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> Enrol(int eventId, [FromBody] EnrolRequest req)
        {
            var participantId = HttpContext.Session.GetInt32("UserId")!.Value;

            var ev = await _db.Events.FindAsync(eventId);
            if (ev == null) return NotFound(new { message = "Event not found." });

            var cat = await _db.Categories
                .FirstOrDefaultAsync(c => c.CategoryId == req.CategoryId && c.EventId == eventId);
            if (cat == null)
                return BadRequest(new { message = "Category not found for this event." });

            var currentCount = await _db.Enrolments
                .CountAsync(e => e.CategoryId == req.CategoryId && e.Status == "Confirmed");
            if (currentCount >= cat.MaxParticipants)
                return BadRequest(new { message = "Category is full." });

            var duplicate = await _db.Enrolments.AnyAsync(e =>
                e.ParticipantId == participantId &&
                e.EventId == eventId &&
                e.CategoryId == req.CategoryId);
            if (duplicate)
                return Conflict(new { message = "You are already enrolled in this category." });

            var enrolment = new Enrolment
            {
                ParticipantId = participantId,
                EventId = eventId,
                CategoryId = req.CategoryId,
                Status = "Confirmed",
                EnrolmentDate = DateTime.UtcNow
            };

            _db.Enrolments.Add(enrolment);
            await _db.SaveChangesAsync();

            return StatusCode(201, enrolment);
        }

        /// <summary>
        /// Get all enrolments of the current participant.
        /// </summary>
        [HttpGet("enrollments/me")]
        [SessionAuth("Participant")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> MyEnrolments()
        {
            var participantId = HttpContext.Session.GetInt32("UserId")!.Value;

            var list = await _db.Enrolments
                .Include(e => e.Event)
                .Include(e => e.Category)
                .Where(e => e.ParticipantId == participantId)
                .Select(e => new
                {
                    e.EnrolmentId,
                    e.Status,
                    e.BibNumber,
                    e.EnrolmentDate,
                    Event = new { e.Event.EventId, e.Event.Name, e.Event.EventDate },
                    Category = new
                    {
                        e.Category.CategoryId,
                        e.Category.Name,
                        e.Category.DistanceKm
                    }
                })
                .ToListAsync();

            return Ok(list);
        }

        /// <summary>
        /// Get all enrolments for an event (Organiser only).
        /// </summary>
        [HttpGet("events/{eventId}/enrollments")]
        [SessionAuth("Organiser")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetForEvent(int eventId)
        {
            var organiserId = HttpContext.Session.GetInt32("UserId")!.Value;
            var ev = await _db.Events.FindAsync(eventId);

            if (ev == null) return NotFound();
            if (ev.OrganiserId != organiserId)
                return StatusCode(403, new { message = "Access denied." });

            var list = await _db.Enrolments
                .Include(e => e.Participant)
                .Include(e => e.Category)
                .Where(e => e.EventId == eventId)
                .Select(e => new
                {
                    e.EnrolmentId,
                    e.Status,
                    e.BibNumber,
                    Participant = new
                    {
                        e.Participant.UserId,
                        e.Participant.FirstName,
                        e.Participant.LastName,
                        e.Participant.Email
                    },
                    Category = new { e.Category.CategoryId, e.Category.Name }
                })
                .ToListAsync();

            return Ok(list);
        }

        /// <summary>
        /// Get a single enrolment by ID (participant or organiser of parent event).
        /// </summary>
        [HttpGet("enrollments/{id}")]
        [SessionAuth]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId")!.Value;
            var role = HttpContext.Session.GetString("Role");

            var enrolment = await _db.Enrolments
                .Include(e => e.Event)
                .Include(e => e.Category)
                .Include(e => e.Participant)
                .FirstOrDefaultAsync(e => e.EnrolmentId == id);

            if (enrolment == null) return NotFound();

            if (role == "Participant" && enrolment.ParticipantId != userId)
                return StatusCode(403, new { message = "Access denied." });

            if (role == "Organiser" && enrolment.Event.OrganiserId != userId)
                return StatusCode(403, new { message = "Access denied." });

            return Ok(enrolment);
        }

        /// <summary>
        /// Update enrolment status (e.g. cancel). Participant can update their own.
        /// </summary>
        [HttpPut("enrollments/{id}")]
        [SessionAuth]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] EnrolStatusUpdate req)
        {
            var userId = HttpContext.Session.GetInt32("UserId")!.Value;
            var role = HttpContext.Session.GetString("Role");

            var enrolment = await _db.Enrolments
                .Include(e => e.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentId == id);

            if (enrolment == null) return NotFound();

            if (role == "Participant" && enrolment.ParticipantId != userId)
                return StatusCode(403, new { message = "Access denied." });

            if (role == "Organiser" && enrolment.Event.OrganiserId != userId)
                return StatusCode(403, new { message = "Access denied." });

            if (req.Status != "Pending" && req.Status != "Confirmed" && req.Status != "Cancelled")
                return BadRequest(new { message = "Invalid status." });

            enrolment.Status = req.Status;
            await _db.SaveChangesAsync();

            return Ok(enrolment);
        }

        public class EnrolRequest
        {
            public int CategoryId { get; set; }
        }

        public class EnrolStatusUpdate
        {
            public string Status { get; set; } = "Cancelled";
        }
    }
}