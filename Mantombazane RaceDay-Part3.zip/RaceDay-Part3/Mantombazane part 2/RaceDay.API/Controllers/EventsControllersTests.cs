﻿using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using RaceDay.API.Controllers;
using RaceDay.API.Models;
using RaceDay.Tests.Helpers;
using Xunit;

namespace RaceDay.Tests.Controllers
{
    public class EventsControllerTests
    {
        private static User CreateOrganiser(int id = 1) => new User
        {
            UserId = id,
            FirstName = "Org",
            LastName = "One",
            Email = $"org{id}@test.com",
            PasswordHash = "hash",
            Role = "Organiser"
        };

        // -------------------- GET ALL --------------------

        [Fact]
        public async Task GetAll_Returns200WithEvents()
        {
            using var db = TestDbFactory.Create();
            db.Users.Add(CreateOrganiser());
            db.Events.AddRange(
                new Event
                {
                    EventId = 1,
                    OrganiserId = 1,
                    Name = "Joburg Run",
                    EventDate = DateTime.UtcNow.AddDays(10),
                    Location = "JHB",
                    EventType = "Running",
                    Status = "Upcoming"
                },
                new Event
                {
                    EventId = 2,
                    OrganiserId = 1,
                    Name = "Cape Cycle",
                    EventDate = DateTime.UtcNow.AddDays(20),
                    Location = "CPT",
                    EventType = "Cycling",
                    Status = "Upcoming"
                });
            await db.SaveChangesAsync();

            var controller = new EventsController(db);
            var result = await controller.GetAll(null);

            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetAll_WithStatusFilter_Returns200()
        {
            using var db = TestDbFactory.Create();
            db.Users.Add(CreateOrganiser());
            db.Events.Add(new Event
            {
                OrganiserId = 1,
                Name = "Filtered",
                EventDate = DateTime.UtcNow.AddDays(1),
                Location = "L",
                EventType = "Running",
                Status = "Open"
            });
            await db.SaveChangesAsync();

            var controller = new EventsController(db);
            var result = await controller.GetAll("Open");

            result.Should().BeOfType<OkObjectResult>();
        }

        // -------------------- GET BY ID --------------------

        [Fact]
        public async Task GetById_ExistingEvent_Returns200()
        {
            using var db = TestDbFactory.Create();
            db.Users.Add(CreateOrganiser());
            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "Race",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "JHB",
                EventType = "Running",
                Status = "Upcoming"
            });
            await db.SaveChangesAsync();

            var controller = new EventsController(db);
            var result = await controller.GetById(1);

            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetById_NonExistentEvent_Returns404()
        {
            using var db = TestDbFactory.Create();
            var controller = new EventsController(db);

            var result = await controller.GetById(999);
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        // -------------------- CREATE --------------------

        [Fact]
        public async Task Create_AsOrganiser_Returns201()
        {
            using var db = TestDbFactory.Create();
            db.Users.Add(CreateOrganiser());
            await db.SaveChangesAsync();

            var controller = new EventsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(1, "Organiser")
            };

            var newEvent = new Event
            {
                Name = "Test Race",
                Description = "Desc",
                EventDate = DateTime.UtcNow.AddDays(30),
                Location = "Durban",
                EventType = "Running",
                Status = "Upcoming"
            };

            var result = await controller.Create(newEvent);

            result.Should().BeOfType<ObjectResult>()
                .Which.StatusCode.Should().Be(201);

            db.Events.Should().HaveCount(1);
        }

        // -------------------- UPDATE --------------------

        [Fact]
        public async Task Update_OwnerOrganiser_Returns200()
        {
            using var db = TestDbFactory.Create();
            db.Users.Add(CreateOrganiser());
            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "Old Name",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "JHB",
                EventType = "Running",
                Status = "Upcoming"
            });
            await db.SaveChangesAsync();

            var controller = new EventsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(1, "Organiser")
            };

            var updated = new Event
            {
                Name = "New Name",
                Description = "Updated",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "JHB",
                EventType = "Running",
                Status = "Open"
            };

            var result = await controller.Update(1, updated);

            result.Should().BeOfType<OkObjectResult>();
            (await db.Events.FindAsync(1))!.Name.Should().Be("New Name");
        }

        [Fact]
        public async Task Update_NonOwnerOrganiser_Returns403()
        {
            using var db = TestDbFactory.Create();
            db.Users.AddRange(CreateOrganiser(1), CreateOrganiser(2));
            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "Owned by 1",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "JHB",
                EventType = "Running",
                Status = "Upcoming"
            });
            await db.SaveChangesAsync();

            var controller = new EventsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Organiser")
            };

            var result = await controller.Update(1, new Event
            {
                Name = "Hack",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "X",
                EventType = "Running",
                Status = "Upcoming"
            });

            var obj = result.Should().BeOfType<ObjectResult>().Subject;
            obj.StatusCode.Should().Be(403);
        }

        [Fact]
        public async Task Update_NonExistentEvent_Returns404()
        {
            using var db = TestDbFactory.Create();
            db.Users.Add(CreateOrganiser());
            await db.SaveChangesAsync();

            var controller = new EventsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(1, "Organiser")
            };

            var result = await controller.Update(999, new Event
            {
                Name = "X",
                EventDate = DateTime.UtcNow,
                Location = "X",
                EventType = "Running",
                Status = "Upcoming"
            });

            result.Should().BeOfType<NotFoundObjectResult>();
        }

        // -------------------- DELETE --------------------

        [Fact]
        public async Task Delete_OwnerOrganiser_Returns204()
        {
            using var db = TestDbFactory.Create();
            db.Users.Add(CreateOrganiser());
            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "Delete Me",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "JHB",
                EventType = "Running",
                Status = "Upcoming"
            });
            await db.SaveChangesAsync();

            var controller = new EventsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(1, "Organiser")
            };

            var result = await controller.Delete(1);

            result.Should().BeOfType<NoContentResult>();
            (await db.Events.FindAsync(1)).Should().BeNull();
        }

        [Fact]
        public async Task Delete_NonOwnerOrganiser_Returns403()
        {
            using var db = TestDbFactory.Create();
            db.Users.AddRange(CreateOrganiser(1), CreateOrganiser(2));
            db.Events.Add(new Event
            {
                EventId = 1,
                OrganiserId = 1,
                Name = "Event",
                EventDate = DateTime.UtcNow.AddDays(5),
                Location = "JHB",
                EventType = "Running",
                Status = "Upcoming"
            });
            await db.SaveChangesAsync();

            var controller = new EventsController(db)
            {
                ControllerContext = FakeSessionHelper.CreateContext(2, "Organiser")
            };

            var result = await controller.Delete(1);

            var obj = result.Should().BeOfType<ObjectResult>().Subject;
            obj.StatusCode.Should().Be(403);
        }
    }
}