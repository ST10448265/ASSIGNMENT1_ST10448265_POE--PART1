# RaceDay – Part 3

ASP.NET Core MVC front end for the RaceDay Part 2 REST API. See [README-PART3.md](README-PART3.md) for setup, configuration, Docker commands and integration notes.

The MVC project consumes the API over HTTP and intentionally contains no direct database access.
