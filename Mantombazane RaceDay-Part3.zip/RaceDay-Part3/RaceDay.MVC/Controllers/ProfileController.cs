using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;
public class ProfileController(RaceDayApiClient api) : Controller
{
    public async Task<IActionResult> Index()
    {
        if (HttpContext.Session.GetInt32("UserId") is null) return RedirectToAction("Login", "Auth");
        var r = await api.SendAsync(HttpMethod.Get, "api/users/profile");
        return View(r.Data);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Update(string firstName, string lastName, string email, string phone)
    {
        var r = await api.SendAsync(HttpMethod.Put, "api/users/profile", new { firstName, lastName, email, phone });
        TempData["Message"] = r.Message;
        return RedirectToAction(nameof(Index));
    }
}
