using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;
public class OrganiserController(RaceDayApiClient api) : Controller
{
    private bool Allowed() => HttpContext.Session.GetString("Role") == "Organiser";
    public async Task<IActionResult> Index()
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Get, "api/events");
        ViewBag.Error = r.Ok ? null : r.Message;
        if (!r.Ok || r.Data.ValueKind != System.Text.Json.JsonValueKind.Array) return View(r.Data);
        var id = HttpContext.Session.GetInt32("UserId");
        var owned = r.Data.EnumerateArray()
            .Where(e => e.TryGetProperty("organiserId", out var owner) && owner.GetInt32() == id)
            .ToArray();
        using var document = System.Text.Json.JsonDocument.Parse(System.Text.Json.JsonSerializer.Serialize(owned));
        return View(document.RootElement.Clone());
    }
    [HttpGet] public IActionResult CreateEvent() => Allowed() ? View() : Forbid();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateEvent(string name, string description, DateTime eventDate, string location, string eventType, string status, IFormFile? banner)
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Post, "api/events", new { name, description, eventDate, location, eventType, status });
        if (!r.Ok) { ModelState.AddModelError("", r.Message); return View(); }
        if (banner is { Length: > 0 } && r.Data.TryGetProperty("eventId", out var id))
            await api.UploadAsync($"api/events/{id.GetInt32()}/banner", banner);
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Enrolments(int eventId)
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Get, $"api/events/{eventId}/enrollments");
        return View("JsonData", r.Data);
    }
    public async Task<IActionResult> Results(int eventId)
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Get, $"api/events/{eventId}/results");
        ViewBag.EventId = eventId;
        return View("Results", r.Data);
    }
    [HttpGet] public IActionResult AddCategory(int eventId) => Allowed() ? View(new CategoryForm { EventId = eventId }) : Forbid();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCategory(CategoryForm form)
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Post, $"api/events/{form.EventId}/categories",
            new { name = form.Name, distanceKm = form.DistanceKm, maxParticipants = form.MaxParticipants, entryFee = form.EntryFee, minAge = form.MinAge, maxAge = form.MaxAge });
        if (!r.Ok) { ModelState.AddModelError("", r.Message); return View(form); }
        return RedirectToAction(nameof(Index));
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> RecordResult(int enrolmentId, string finishTime, int? position, string resultStatus)
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Post, $"api/enrollments/{enrolmentId}/result",
            new { finishTime, position, resultStatus });
        TempData["Message"] = r.Message;
        return RedirectToAction(nameof(Index));
    }
    public sealed class CategoryForm
    {
        public int EventId { get; set; }
        public string Name { get; set; } = "";
        public decimal DistanceKm { get; set; }
        public int MaxParticipants { get; set; }
        public decimal EntryFee { get; set; }
        public int MinAge { get; set; }
        public int MaxAge { get; set; }
    }
}
