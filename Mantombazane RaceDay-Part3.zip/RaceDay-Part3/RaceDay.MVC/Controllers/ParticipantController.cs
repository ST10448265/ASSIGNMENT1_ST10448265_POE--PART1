using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;
public class ParticipantController(RaceDayApiClient api) : Controller
{
    private bool Allowed() => HttpContext.Session.GetString("Role") == "Participant";
    public async Task<IActionResult> MyEnrolments()
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Get, "api/enrollments/me");
        return View("JsonData", r.Data);
    }
    public async Task<IActionResult> MyResults()
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Get, "api/enrollments/me/results");
        return View("JsonData", r.Data);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(int eventId, int categoryId)
    {
        if (!Allowed()) return Forbid();
        var r = await api.SendAsync(HttpMethod.Post, $"api/events/{eventId}/enrol", new { categoryId });
        TempData["Message"] = r.Message;
        return RedirectToAction("Details", "Events", new { id = eventId });
    }
}
