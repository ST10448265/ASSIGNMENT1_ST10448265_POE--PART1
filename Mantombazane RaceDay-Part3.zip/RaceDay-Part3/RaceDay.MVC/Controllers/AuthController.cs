using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;
public class AuthController(RaceDayApiClient api) : Controller
{
    [HttpGet] public IActionResult Login() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string email, string password)
    {
        var result = await api.LoginAsync(new { email, password });
        if (!result.Ok) { ModelState.AddModelError("", result.Message); return View(); }
        var d = result.Data;
        HttpContext.Session.SetInt32("UserId", d.GetProperty("userId").GetInt32());
        HttpContext.Session.SetString("Role", d.GetProperty("role").GetString() ?? "");
        HttpContext.Session.SetString("UserName", d.TryGetProperty("firstName", out var n) ? n.GetString() ?? "" : "");
        return RedirectToAction("Index", "Home");
    }
    [HttpGet] public IActionResult Register() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(string firstName, string lastName, string email, string password, string phone, string role = "Participant")
    {
        var r = await api.SendAsync(HttpMethod.Post, "api/auth/register", new { firstName, lastName, email, password, phone, role });
        if (!r.Ok) { ModelState.AddModelError("", r.Message); return View(); }
        TempData["Message"] = "Account created. Please log in.";
        return RedirectToAction(nameof(Login));
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await api.SendAsync(HttpMethod.Post, "api/auth/logout");
        HttpContext.Session.Clear();
        return RedirectToAction(nameof(Login));
    }
}
