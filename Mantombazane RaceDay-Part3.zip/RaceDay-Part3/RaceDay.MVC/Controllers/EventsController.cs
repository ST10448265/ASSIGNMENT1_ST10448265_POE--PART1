using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;
public class EventsController(RaceDayApiClient api) : Controller
{
    public async Task<IActionResult> Index()
    {
        var r = await api.SendAsync(HttpMethod.Get, "api/events");
        ViewBag.Error = r.Ok ? null : r.Message;
        return View(r.Data);
    }
    public async Task<IActionResult> Details(int id)
    {
        var r = await api.SendAsync(HttpMethod.Get, $"api/events/{id}");
        if (!r.Ok) return NotFound();
        return View(r.Data);
    }
}
