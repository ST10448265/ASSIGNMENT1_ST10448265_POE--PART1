using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace RaceDay.MVC.Services;

public sealed class RaceDayApiClient
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _accessor;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public RaceDayApiClient(HttpClient http, IHttpContextAccessor accessor)
    {
        _http = http;
        _accessor = accessor;
    }

    private HttpRequestMessage Create(HttpMethod method, string route, object? body = null)
    {
        var request = new HttpRequestMessage(method, route);
        var cookie = _accessor.HttpContext?.Session.GetString("ApiSessionCookie");
        if (!string.IsNullOrWhiteSpace(cookie)) request.Headers.Add("Cookie", cookie);
        if (body is not null)
            request.Content = new StringContent(JsonSerializer.Serialize(body, JsonOptions), Encoding.UTF8, "application/json");
        return request;
    }

    public async Task<(bool Ok, string Message, JsonElement Data, HttpStatusCode Status)> SendAsync(
        HttpMethod method, string route, object? body = null, CancellationToken cancellationToken = default)
    {
        using var request = Create(method, route, body);
        using var response = await _http.SendAsync(request, cancellationToken);
        var raw = await response.Content.ReadAsStringAsync(cancellationToken);
        JsonElement data;
        try { using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(raw) ? "{}" : raw); data = doc.RootElement.Clone(); }
        catch { data = JsonDocument.Parse("{}").RootElement.Clone(); }

        var message = data.ValueKind == JsonValueKind.Object && data.TryGetProperty("message", out var msg)
            ? msg.ToString() : response.IsSuccessStatusCode ? "Request completed." : $"API request failed ({(int)response.StatusCode}).";

        return (response.IsSuccessStatusCode, message, data, response.StatusCode);
    }

    public async Task<(bool Ok, string Message, JsonElement Data)> LoginAsync(object credentials)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/auth/login")
        { Content = new StringContent(JsonSerializer.Serialize(credentials, JsonOptions), Encoding.UTF8, "application/json") };
        using var response = await _http.SendAsync(request);
        var raw = await response.Content.ReadAsStringAsync();
        JsonElement data;
        try { using var doc = JsonDocument.Parse(raw); data = doc.RootElement.Clone(); }
        catch { data = JsonDocument.Parse("{}").RootElement.Clone(); }
        if (response.IsSuccessStatusCode)
        {
            var setCookie = response.Headers.TryGetValues("Set-Cookie", out var values)
                ? values.FirstOrDefault(v => v.StartsWith(".AspNetCore.Session=", StringComparison.OrdinalIgnoreCase))
                : null;
            if (setCookie is not null)
            {
                var cookiePair = setCookie.Split(';', 2)[0];
                _accessor.HttpContext!.Session.SetString("ApiSessionCookie", cookiePair);
            }
        }
        var message = data.ValueKind == JsonValueKind.Object && data.TryGetProperty("message", out var m) ? m.ToString() : response.ReasonPhrase ?? "Login failed.";
        return (response.IsSuccessStatusCode, message, data);
    }

    public async Task<(bool Ok, string Message)> UploadAsync(string route, IFormFile file, CancellationToken ct = default)
    {
        using var request = Create(HttpMethod.Post, route);
        using var content = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        content.Add(fileContent, "file", Path.GetFileName(file.FileName));
        request.Content = content;
        using var response = await _http.SendAsync(request, ct);
        var raw = await response.Content.ReadAsStringAsync(ct);
        return (response.IsSuccessStatusCode, string.IsNullOrWhiteSpace(raw) ? response.ReasonPhrase ?? "Upload failed." : raw);
    }
}
