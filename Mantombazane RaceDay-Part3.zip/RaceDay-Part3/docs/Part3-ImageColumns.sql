-- Apply this script to the existing RaceDay Part 2 database before using image uploads.
IF COL_LENGTH('dbo.EVENTS', 'BannerImageUrl') IS NULL
    ALTER TABLE dbo.EVENTS ADD BannerImageUrl NVARCHAR(2048) NULL;
IF COL_LENGTH('dbo.USERS', 'ProfilePictureUrl') IS NULL
    ALTER TABLE dbo.USERS ADD ProfilePictureUrl NVARCHAR(2048) NULL;
