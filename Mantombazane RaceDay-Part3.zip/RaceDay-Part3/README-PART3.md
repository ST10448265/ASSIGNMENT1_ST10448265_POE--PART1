# RaceDay – Part 3 MVC Web Application

## Solution contents
- `RaceDay.API`: supplied Part 2 API source.
- `RaceDay.MVC`: ASP.NET Core MVC client. It calls the API using HTTP and does not connect directly to the database.
- `RaceDay.Tests`: supplied Part 2 test project.

## Requirements
- .NET 8 SDK
- SQL Server and the configured Part 2 database
- Part 2 API running
- Azure Storage account if image upload endpoints are enabled

## Configure and run
1. Configure the API database connection in `RaceDay.API/appsettings.json` or user secrets.
2. Start the API from the `RaceDay.API` folder: `dotnet run`.
3. Set `ApiSettings:BaseUrl` in `RaceDay.MVC/appsettings.json` to the API HTTPS address shown by the API. The supplied API routes are `/api/users/profile`, `/api/events/{id}/enrol`, `/api/enrollments/me` and `/api/results/me`; the MVC client uses these route names.
4. In another terminal, run:
   `dotnet run --project RaceDay.MVC`
5. Open the MVC URL printed by `dotnet run`.

The API uses ASP.NET Core session state. The MVC client retains the API session cookie server-side and forwards it for subsequent API calls. Keep both applications on HTTPS in deployment.

## Docker
Build the MVC image from the repository root:
`docker build -f RaceDay.MVC/Dockerfile -t raceday-mvc .`

Run it (replace the API URL with a host reachable from the container):
`docker run --rm -p 8080:8080 -e ApiSettings__BaseUrl=http://host.docker.internal:7000/ raceday-mvc`

On Linux, if required, add `--add-host=host.docker.internal:host-gateway`. The API must also be running and reachable.

## Important integration notes
- The supplied Part 2 API is the source of truth for business logic and database access.
- The MVC app is a client only; do not add an EF Core DbContext or SQL connection to it.
- The Part 3 package adds API upload routes for event banners and profile pictures. Apply `docs/Part3-ImageColumns.sql` to the existing database and configure the Azure connection string before testing uploads. Image links are returned by the API and the event details page displays the event banner.
- Verify actual API routes and response shapes against Swagger. The personal results route and some enrolment operations may need an API endpoint added in Part 2 before the corresponding page can display data.
- For production, protect organiser account creation; do not allow public self-registration as Organiser.

## GitHub Actions
The workflow in `.github/workflows/dotnet.yml` restores, builds and tests the API and builds the MVC project.

## Azure Blob Storage configuration
Set the API secret without committing credentials:
`dotnet user-secrets init --project "Mantombazane part 2/RaceDay.API"`
`dotnet user-secrets set "AzureBlobStorage:ConnectionString" "<your Azure Storage connection string>" --project "Mantombazane part 2/RaceDay.API"`

The upload API validates image MIME type and limits files to 5 MB. The blob container is created if it does not exist. For production, use managed identity or another secret provider rather than committing a storage connection string.
